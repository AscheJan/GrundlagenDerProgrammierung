
public abstract class Lebensmittel {

	// Attribute
	protected String name;
	protected int menge; // in Milliliter bzw. Gramm

	// Konstruktor
	public Lebensmittel(String name, int menge) {
		this.name = name;
		this.menge = menge;
	}

	// Methode
	public abstract boolean essen();//g
	
	public abstract boolean trinken();//ml

	
	//Namen der Klasse und die Instanzvariable name und menge zurückgeben
	public String status() {

	return this.getClass().getName()+" ("+this.name+", "+this.menge; //Menge Einheit
	}
}