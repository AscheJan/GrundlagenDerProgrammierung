
public class Kaese extends Speise {

	// Attribute

	// Konstruktor
	public Kaese(String name, int menge) {
		super(name, menge);
	}
	// Methode

	public boolean essen() {
		if (menge >= 20) {
			menge -= 20;
			return true;
		}
		menge = 0;
		return false;
	}
}
