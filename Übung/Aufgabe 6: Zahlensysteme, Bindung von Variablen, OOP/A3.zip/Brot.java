
public class Brot extends Speise{

	
	//Attribute
	int Weißbrot = 0;
	int Schwarzbrot = 1;
	int Mischbrot = 2;
	int Spezialbrot;
	
	static String brotWal[] = new String [] {
			"Weißbrot",			//0
			"Schwarzbrot",		//1
			"Mischbrot",		//2
			"Spezialbrot"		//französicherRumToast
	};
	
	
	
	//Konstruktor
		public Brot(int name, int menge) {
			super(brotWal[name],menge);
			
		}
	//Methode
		
		public boolean essen() {
			if (menge >= 50) {
				menge-=50;
				return true;
			}
			menge = 0;
			return false;	
			
		}
}
