
public class Getraenk extends Lebensmittel{

	
	//Attribute
	String einheitGetrank = " ml)";
	//Konstruktor
		public Getraenk(String name, int menge) {
			super(name, menge);
		}
	//Methode
	
		public boolean trinken() {
			if(menge >= 0) {
				menge = 0;
				return false;
			}else
				return true;
		}

		@Override
		public boolean essen() {
			return false;
		}
		
		public String status() {

			return  super.status() + einheitGetrank;}
}
