
public class Wasser extends Getraenk{

	
	//Attribute
	
	//Konstruktor
	public Wasser (String name, int menge) {
		super(name,menge);
		
	}
	
	//Methode
	public boolean trinken() {
		if (menge >= 200) {
			menge-=200;
			return true;
		}
		menge = 0;
		return false;
	}
	
}
