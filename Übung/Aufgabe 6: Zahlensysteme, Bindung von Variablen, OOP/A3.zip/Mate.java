
public class Mate extends Getraenk{

	
	//Attribute
	private static int mengemate = 500;
	//Konstruktor
		public Mate (String name) {
			super(name,mengemate);
			
		}
	//Methode	
		public boolean trinken() {
			if (menge >= 100) {
				menge-=100;
				return true;
			}
			menge = 0;
			return false;
		}
}
