
public class Speise extends Lebensmittel{

	//Attribute
	String einheitSpeise = " g)";
	//Konstruktor
		public Speise (String name, int menge) {
			super(name, menge);
		}
	//Methode
		public boolean essen() {
			if(menge >= 0) {
				menge = 0;
				return false;
			}else
				return true;
		}
		public boolean trinken() {
			return false;
		}
		public String status() {

			return  super.status() + einheitSpeise;}
}
